package com.cqcet.emarket.entity;

import com.cqcet.emarket.common.BaseEntity;

/**
 * 用户信息
 */

public class UserInfo extends BaseEntity {
    /**
     * 用户名称
     */
    private String name;
    /**
     * 登录账号
     */
    private String loginName;
    /**
     * 密码
     */
    private String password;
    /**
     * 头像路径
     */
    private String avatar;
    /**
     * 电子邮件
     */
    private String email;
    /**
     * 手机号
     */
    private String phone;


    public UserInfo() {
    }

    public UserInfo(String name, String loginName, String phone, String password) {
        this.name = name;
        this.loginName = loginName;
        this.phone = phone;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "UserInfo{" +
                "id='" + getId() + '\'' +
                ", name='" + name + '\'' +
                ", loginName='" + loginName + '\'' +
                ", avatar='" + avatar + '\'' +
                ", email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                ", password='" + password + '\'' +
                ", delFlag=" + getDelFlag() + '\'' +
                ", createBy=" + getCreateBy() + '\'' +
                ", createTime=" + getCreateTime() + '\'' +
                ", updateBy=" + getUpdateBy() + '\'' +
                ", updateTime=" + getUpdateTime() + '\'' +
                ", REMARK=" + getRemark() + '\'' +
                '}';
    }
}
