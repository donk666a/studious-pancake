package com.cqcet.emarket.dao.impl;

import com.cqcet.emarket.dao.ProductInfoDao;
import com.cqcet.emarket.entity.ProductInfo;
import com.cqcet.emarket.entity.UserInfo;
import cqcet.aibd.soft.ObjectUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class ProductInfoDaoImp implements ProductInfoDao {

    @Override
    public List<ProductInfo> selectProductInfoList(ProductInfo productInfo) throws Exception {
        if (productInfo != null) {
            return selectProductInfoByProductParams(productInfo);
        } else {
            String sql = "select * from product_info where delFlag='1'";
            return new ObjectUtil<ProductInfo>().getList(sql, ProductInfo.class);
        }
    }

    private List<ProductInfo> selectProductInfoByProductParams(ProductInfo productInfo) throws Exception {
        //是否输入了多个查询条件
        String sql = "select * from product_info where delFlag='1' and IFNULL(productName,'') like ?";

        if (productInfo.getId() != null) {
            sql = sql + " and id=?";
            return new ObjectUtil<ProductInfo>().getList(sql, ProductInfo.class,
                    "%" + productInfo.getProductName() + "%",
                    productInfo.getId());
        } else {
            return new ObjectUtil<ProductInfo>().getList(sql, ProductInfo.class,
                    "%" + productInfo.getProductName() + "%");
        }
    }

    @Override
    public ProductInfo selectProductInfoById(Integer id) throws Exception {
        String sql = "select * from product_info where id = ? and delFlag='1'";
        return new ObjectUtil<ProductInfo>().getOne(sql, ProductInfo.class, id);
    }
}
