package com.cqcet.emarket.dao.impl;

import com.cqcet.emarket.dao.UserInfoDao;
import com.cqcet.emarket.entity.UserInfo;
import cqcet.aibd.soft.ObjectUtil;

import java.util.List;


public class UserInfoDaoImpl implements UserInfoDao {

    @Override
    public List<UserInfo> selectUserInfoList(UserInfo userInfo) throws Exception {
        if (userInfo != null) {
            return selectUserInfoByUserParams(userInfo);
        }else{
            String sql = "select * from user_info where delFlag='1'";
            return new ObjectUtil<UserInfo>().getList(sql, UserInfo.class);
        }
    }

    /**
     * 通过userinfo对象中包含的属性查询用户，能实现查询的属性id，loginName，phone，email
     *
     * @param userInfo
     * @return
     */
    private List<UserInfo> selectUserInfoByUserParams(UserInfo userInfo) throws Exception {
        //是否输入了多个查询条件
        String sql = "select * from user_info where delFlag='1' and IFNULL(name,'') like ? and IFNULL(loginName,'') like ? and IFNULL(email,'') like ? and IFNULL(phone,'') like ?";

        if (userInfo.getId() != null) {
            sql = sql + " and id=?";
            return new ObjectUtil<UserInfo>().getList(sql, UserInfo.class,
                    "%" + userInfo.getName() + "%",
                    "%" + userInfo.getLoginName() + "%",
                    "%" + userInfo.getEmail()+ "%",
                    "%" + userInfo.getPhone()+ "%",
                     userInfo.getId());
        } else {
            return new ObjectUtil<UserInfo>().getList(sql, UserInfo.class,
                    "%" + userInfo.getName() + "%",
                    "%" + userInfo.getLoginName() + "%",
                    "%" + userInfo.getEmail()+ "%",
                    "%" + userInfo.getPhone()+ "%");
        }
    }

    @Override
    public UserInfo selectUserInfoByLoginName(String loginName) {
        String sql = "select * from user_info where loginName = ? and delFlag='1'";
        return new ObjectUtil<UserInfo>().getOne(sql, UserInfo.class, loginName);
    }

    @Override
    public UserInfo selectUserInfoByPhone(String phone) {
        String sql = "select * from user_info where phone=? and delFlag='1'";
        return new ObjectUtil<UserInfo>().getOne(sql, UserInfo.class, phone);
    }

    @Override
    public UserInfo selectUserInfoByEmail(String email) {
        String sql = "select * from user_info where email = ? and delFlag='1'";
        return new ObjectUtil<UserInfo>().getOne(sql, UserInfo.class, email);
    }

    @Override
    public UserInfo selectUserInfoById(Integer userInfoId) throws Exception {
        String sql = "select * from user_info where id = ? and delFlag='1'";
        return new ObjectUtil<UserInfo>().getOne(sql, UserInfo.class, userInfoId);
    }

    @Override
    public UserInfo selectUserInfoByIdIncDel(Integer id) {
        String sql = "select * from user_info where id=?";
        return new ObjectUtil<UserInfo>().getOne(sql, UserInfo.class, id);
    }

    @Override
    public List<UserInfo> selectUserInfoByName(String name) {
        String sql = "select * from user_info WHERE name like ? and delFlag='1'";
        return new ObjectUtil<UserInfo>().getList(sql, UserInfo.class, "%" + name + "%");
    }

    @Override
    public int deleteUserInfoById(Integer userInfoId) {
        //软删，修改delFlag字段
        String sql = "update user_info set delFlag=0 where id=?";
        return new ObjectUtil<UserInfo>().update(sql, userInfoId);
    }

    @Override
    public int updateUserInfo(Integer id, UserInfo userInfo) {
        if (userInfo == null) {
            return 0;
        }
        //更新的数据和set后面的字段名一一对应
        String sql = "update user_info set name=?,loginName=?,phone=?,email=?,avatar=? where id=?";
        return new ObjectUtil<UserInfo>().update(sql, userInfo.getName(), userInfo.getLoginName(),
                userInfo.getPhone(), userInfo.getEmail(),userInfo.getAvatar(), id);
    }

    @Override
    public int insertUserInfo(UserInfo userInfo) {
        //user_info　13个字段,填写12个,id自动
        String sql = "insert into user_info(`name`,`loginName`,`password`,`phone`,`email`,`avatar`,`createBy`,`createTime`,`updateBy`,`updateTime`,`delFlag`,`remark`) value(?,?,?,?,?,?,?,?,?,?,?,?)";
        if (userInfo == null) {
            return 0;
        }
        return new ObjectUtil<UserInfo>().add(sql, userInfo.getName(), userInfo.getLoginName(), userInfo.getPassword(),
                userInfo.getPhone(), userInfo.getEmail(), userInfo.getAvatar(),
                userInfo.getCreateBy(), userInfo.getCreateTime(), userInfo.getUpdateBy(),
                userInfo.getUpdateTime(), userInfo.getDelFlag(), userInfo.getRemark());
    }

    @Override
    public int checkLoginNameUnique(String loginName) {
        //dbutils的query方法传入的T 类型参数需要空构造方法，否则报空指针
        String sql = "select * from user_info where loginName= ?";
        List<UserInfo> users = new ObjectUtil<UserInfo>().getList(sql, UserInfo.class, loginName);
        return users.size();
    }

    @Override
    public UserInfo checkPhoneUnique(String phonenumber) {
        return null;
    }

    @Override
    public UserInfo checkEmailUnique(String email) {
        return null;
    }
}
