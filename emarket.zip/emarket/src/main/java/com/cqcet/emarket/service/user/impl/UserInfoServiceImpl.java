package com.cqcet.emarket.service.user.impl;

import com.cqcet.emarket.service.user.UserInfoService;
import com.cqcet.emarket.service.user.login.PasswordService;
import com.cqcet.emarket.common.UserConstants;
import com.cqcet.emarket.dao.UserInfoDao;
import com.cqcet.emarket.dao.impl.UserInfoDaoImpl;
import com.cqcet.emarket.entity.UserInfo;
import org.apache.commons.lang3.StringUtils;

import java.util.List;


public class UserInfoServiceImpl implements UserInfoService {
    private UserInfoDao userInfoDao;

    public UserInfoServiceImpl() {
        userInfoDao = new UserInfoDaoImpl();
    }

    @Override
    public List<UserInfo> selectUserInfoList(UserInfo userInfo) {
        try {
            return userInfoDao.selectUserInfoList(userInfo);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public UserInfo selectUserInfoByLoginName(String loginName) {
        return userInfoDao.selectUserInfoByLoginName(loginName);
    }

    @Override
    public UserInfo selectUserInfoById(Integer id) {
        try {
            return userInfoDao.selectUserInfoById(id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public int deleteUserInfoById(Integer id) {
        return userInfoDao.deleteUserInfoById(id);
    }

    @Override
    public int insertUserInfo(UserInfo userInfo) {
        if (userInfo.getCreateBy()==null||"".equals(userInfo.getCreateBy())) {
            userInfo.setCreateBy("admin");
        }
        return userInfoDao.insertUserInfo(userInfo);
    }

    @Override
    public boolean registerUserInfo(UserInfo userInfo) {
        String loginName = userInfo.getLoginName();
        String password = userInfo.getPassword();
        if (StringUtils.isEmpty(userInfo.getName())) {
            userInfo.setName(loginName);
        }
        userInfo.setPassword(new PasswordService().encryptPassword(loginName, password));
        int bl = userInfoDao.insertUserInfo(userInfo);
        if (bl == 1) {
            return true;
        }
        //防止可能由于线程池异常，会意外新增2条相同记录
        if (bl > 1) {
            if (UserConstants.USER_NAME_NOT_UNIQUE.equalsIgnoreCase(checkLoginNameUnique(userInfo.getLoginName()))) {
                userInfoDao.deleteUserInfoById(userInfo.getId());
            }
            return true;
        }
        return false;
    }

    @Override
    public int updateUserInfo(Integer id,UserInfo userInfo) {
        return userInfoDao.updateUserInfo(id, userInfo);
    }


    @Override
    public String checkLoginNameUnique(String loginName) {
        int count = userInfoDao.checkLoginNameUnique(loginName);
        return count == 0 ? UserConstants.USER_NAME_UNIQUE : UserConstants.USER_NAME_NOT_UNIQUE;
    }

}
