package com.cqcet.emarket.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson2.JSON;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.IOUtils;
import com.cqcet.emarket.common.AjaxResult;
import com.cqcet.emarket.entity.Picture;
import com.cqcet.emarket.utils.FileUploadUtils;
import com.cqcet.emarket.utils.ServletUtils;

/**
 * 上传图片接口
 */
@WebServlet("/uploadPic")
public class UploadPictureController extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Picture picture = new Picture();
		Map<String, String> map = new HashMap<String, String>();

		DiskFileItemFactory dfif = new DiskFileItemFactory();
		// 设置临时文件存储位置
		System.out.println("temp:"+this.getServletContext().getRealPath("/temp"));
		dfif.setRepository(new File(this.getServletContext().getRealPath("/temp")));
		// 设置上传文件缓存大小为10m
		dfif.setSizeThreshold(1024 * 1024 * 20);
		// 创建上传组件
		ServletFileUpload upload = new ServletFileUpload(dfif);
		// 处理上传文件中文乱码
		upload.setHeaderEncoding("utf-8");
		try {
			// 解析request得到所有的FileItem
			List<FileItem> items = upload.parseRequest(request);
			// 遍历所有FileItem
			for (FileItem item : items) {
				// 判断当前是否是上传组件
				if (!item.isFormField()) {
					// 是上传组件
					// 得到上传文件真实名称
					String fileName = FileUploadUtils.subFileName(item.getName());

					// 得到随机名称
					String randomName = FileUploadUtils.generateRandonFileName(fileName);

					// 图片存储父目录
					//发布时时使用
					String imgurl_parent = "/static/pic";
					File parentDir = new File(this.getServletContext().getRealPath(imgurl_parent));

					//开发时使用绝对路径
//					String imgurl_parent = "C:\\Users\\hasee\\workspace\\test\\WebContent\\productImg";
//					File parentDir = new File(imgurl_parent);

					// 验证目录是否存在，如果不存在，创建出来
					if (!parentDir.exists()) {
						parentDir.mkdirs();
					}
					String imgurl = imgurl_parent+"/" + randomName;
					picture.setUrl(imgurl);
					picture.setPictureName(randomName);
					IOUtils.copy(item.getInputStream(), new FileOutputStream(new File(parentDir, randomName)));
					item.delete();
				}
			}
		} catch (FileUploadException e) {
			e.printStackTrace();
		}

		/* 将响应页面的内容封装到AjaxResult对象中 */
		AjaxResult ajaxResult = AjaxResult.success(picture);

		/* 将字符串渲染到客户端 */
		ServletUtils.renderString(response, JSON.toJSONString(ajaxResult));
	}
}