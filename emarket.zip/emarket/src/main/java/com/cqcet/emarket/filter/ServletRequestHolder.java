package com.cqcet.emarket.filter;

import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebFilter(urlPatterns = "/*")
public class ServletRequestHolder implements Filter {

    private static ThreadLocal<HttpServletRequest> httpServletRequestHolder = new ThreadLocal<>();
    private static ThreadLocal<HttpServletResponse> httpServletResponseHolder = new ThreadLocal<>();


    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {
        // 绑定到当前线程
        httpServletRequestHolder.set((HttpServletRequest) request);
        httpServletResponseHolder.set((HttpServletResponse) response);
        try {
            // 统一字符编码
            request.setCharacterEncoding("utf-8");
            response.setContentType("text/html;charset=utf-8");

            // 未登录过滤
            // 获得子类HttpServletRequest
            HttpServletRequest httpRequest = (HttpServletRequest) request;
            HttpServletResponse httpResponse = (HttpServletResponse) response;
            // 获取session对象，以便获取作用域中的值
            HttpSession session = httpRequest.getSession(true);
            String loginName = (String) session.getAttribute("loginName");
            // 拦截器拦截了所有请求，但是要仅允许登录页面可以通行
            String uri = httpRequest.getRequestURI();
            if (uri.equals("/") || uri.contains("static") || uri.contains("ico")
                    || uri.contains("register.jsp")  || uri.contains("signup")
                    || uri.contains("login.jsp") || uri.contains("login") || StringUtils.isNotEmpty(loginName)) {
                chain.doFilter(request, response);
            } else {
                httpResponse.sendRedirect("/login.jsp");
            }
        } catch (Exception e) {
            throw e;
        } finally {
            httpServletRequestHolder.remove(); // 清理资源引用
            httpServletResponseHolder.remove();
        }
    }

    @Override
    public void destroy() {
    }

    public static HttpServletRequest getRequest() {
        return httpServletRequestHolder.get();
    }

    public static HttpServletResponse getResponse() {
        return httpServletResponseHolder.get();
    }

}
