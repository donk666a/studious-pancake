package com.cqcet.emarket.entity;

import com.cqcet.emarket.common.BaseEntity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 商品信息
 */
public class ProductInfo extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 商品编码
     */
    private String productCode;

    /**
     * 商品名称
     */
    private String productName;

    /**
     * 商品分类
     */
    private String category;

    /**
     * 商品图片
     */
    private String imgUrl;

    /**
     * 商品价格
     */
    private BigDecimal price;

    /**
     * 商品库存
     */
    private Integer count;


    /**
     * 上下架状态
     */
    private Integer publishStatus;

    /**
     * 生成日期
     */
    private Date productionDate;

    /**
     * 商品有效期
     */
    private String shelfLife;

    /**
     * 商品描述
     */
    private String description;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Integer getPublishStatus() {
        return publishStatus;
    }

    public void setPublishStatus(Integer publishStatus) {
        this.publishStatus = publishStatus;
    }

    public Date getProductionDate() {
        return productionDate;
    }

    public void setProductionDate(Date productionDate) {
        this.productionDate = productionDate;
    }

    public String getShelfLife() {
        return shelfLife;
    }

    public void setShelfLife(String shelfLife) {
        this.shelfLife = shelfLife;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "ProductInfo{" +
                "id='" + getId() + '\'' +
                "productCode='" + productCode + '\'' +
                ", productName='" + productName + '\'' +
                ", category='" + category + '\'' +
                ", imgUrl='" + imgUrl + '\'' +
                ", price=" + price +
                ", count=" + count +
                ", publishStatus=" + publishStatus +
                ", productionDate=" + productionDate +
                ", shelfLife='" + shelfLife + '\'' +
                ", description='" + description + '\'' +
                ", delFlag=" + getDelFlag() + '\'' +
                ", createBy=" + getCreateBy() + '\'' +
                ", createTime=" + getCreateTime() + '\'' +
                ", updateBy=" + getUpdateBy() + '\'' +
                ", updateTime=" + getUpdateTime() + '\'' +
                ", REMARK=" + getRemark() + '\'' +
                '}';
    }
}
