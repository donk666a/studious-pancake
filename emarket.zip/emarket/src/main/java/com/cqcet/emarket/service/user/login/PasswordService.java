package com.cqcet.emarket.service.user.login;


import com.cqcet.emarket.entity.UserInfo;
import com.cqcet.emarket.utils.Md5Utils;

/**
 * 登录密码服务类
 */
public class PasswordService {

    public boolean matches(UserInfo user, String password) {
        return user.getPassword().equals(encryptPassword(user.getLoginName(), password));
    }


    public String encryptPassword(String loginName, String password) {
        return Md5Utils.hash(loginName + password);
    }
}
