package com.cqcet.emarket.service.user.login;

import com.cqcet.emarket.service.user.UserInfoService;
import com.cqcet.emarket.entity.UserInfo;
import com.cqcet.emarket.service.user.impl.UserInfoServiceImpl;

/**
 * 登录校验方法
 */
public class LoginService {

    private PasswordService passwordService;

    private UserInfoService userInfoService;

    public LoginService() {
        passwordService = new PasswordService();
        userInfoService = new UserInfoServiceImpl();
    }

    public LoginService(UserInfoService userInfoService, PasswordService passwordService) {
        this.passwordService = passwordService;
        this.userInfoService = userInfoService;
    }

    public LoginService(UserInfoService userInfoService) {
        this.userInfoService = userInfoService;
        passwordService = new PasswordService();
    }

    /**
     * 登录
     */
    public UserInfo login(String username, String password) {
        // 查询用户信息
        UserInfo user = userInfoService.selectUserInfoByLoginName(username);
        if (user != null && passwordService.matches(user, password)) {
            return user;
        }
        return null;
    }
}
