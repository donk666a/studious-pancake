package com.cqcet.emarket.controller.user;

import com.alibaba.fastjson2.JSON;
import com.cqcet.emarket.common.AjaxResult;
import com.cqcet.emarket.entity.UserInfo;
import com.cqcet.emarket.service.user.login.LoginService;
import com.cqcet.emarket.utils.ServletUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;



@WebServlet("/login")
public class LoginController extends HttpServlet {
    private LoginService loginService = new LoginService();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doProcessRequest(req, resp);
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doProcessRequest(req, resp);
    }

    private void doProcessRequest(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        /* 通过ServletUtils工具类的getObjectFromPayload方法，将请求参数转换为一个UserInfo的实例对象 */
        UserInfo userInfo = ServletUtils.getObjectFromPayload(req, UserInfo.class);
        /* userInfo中存储的就是请求数据 */
        if (userInfo != null && userInfo.getLoginName() != null) {
            /* 将响应页面的内容封装到AjaxResult对象中 */
            AjaxResult ajaxResult = ajaxLogin(req, userInfo.getLoginName(), userInfo.getPassword());
            /* 将字符串渲染到客户端 */
            ServletUtils.renderString(resp, JSON.toJSONString(ajaxResult));
        } else {
            resp.sendRedirect("/login.jsp");
        }
    }

    private AjaxResult ajaxLogin(HttpServletRequest req, String loginName, String password) {
        UserInfo userInfo = loginService.login(loginName, password);
        /* 登录成功 */
        if (userInfo != null) {
            req.getSession().setAttribute("loginName", loginName);
            return AjaxResult.success("登录成功");
        }
        return AjaxResult.error("用户或密码错误");
    }
}
